/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <stdlib.h>

int main()
{
        int arr[10],n,i;
        int choice;
        printf("Enter the size of an array?");
        scanf("%d",&n);
        printf("Enter the elements:");
                   for(i=0;i<n;i++)
                     {
                         scanf("%d",&arr[i]);
                     }
        while(1)
           {
               printf("\n 1.Insertion of an element at first position."); 
               printf("\n 2.Insertion of an element at any position.");
               printf("\n 3.Insertion of an element at last position."); 
               printf("\n 4.deletion of an element at first position.");
               printf("\n 5.deletion of an element at any position.");
               printf("\n 6.deletion of element at last position.");
               printf("\n 7.display.");
               printf("\n 8.Exit.");
               
               printf("\n Enter the choice:");
               scanf("\n %d",&choice);
               switch(choice)
               {
                  case 1:
                     printf("Enter the value:");
                     int value;
                     scanf("%d",&value);
                     for(int i=n;i>0;i--)
                     {
                         arr[i]=arr[i-1];
                     }
                     arr[0]=value;
                     n++;
                      break;
                     case 2:
                     printf("Enter the value:");
                     int value1;
                     scanf("%d",&value1);
                     int position;
                     printf("Enter the position:");
                     scanf("%d",&position);
                     for(int i=n;i>=position;i++)
                     {
                         arr[i]=arr[i-1];
                     }
                     arr[position-1]=value1;
                     n++;
                     break;
                     case 3: 
                             printf("Enter the value:");
                     int value2;
                     scanf("%d",&value2);
                     arr[n]=value2;
                     n++;
                     break;
                     case 4: 
                     for(int i=0;i<n;i++)
                     {
                         arr[i]=arr[i+1];
                     }
                     n--;
                     break;
                     case 5: 
                     int position1;
                       printf("Enter the position:");
                       scanf("%d",&position1);
                     for(int i=position1-1;i<n;i++)
                     {
                         arr[i]=arr[+1];
                     }
                     n--;
                     break;
                     case 6: 
                         n--;
                         free(arr[n]);
                     break;
                     case 7: 
                         for(int i=0;i<n;i++)
                         {
                             printf("%d\n",arr[i]);
                         }
                     break;
                     case 8: 
                            exit(0);
                     break;
                     default: 
                          printf("\n Invalid choice!");
                }
           }
           return 0;
}
