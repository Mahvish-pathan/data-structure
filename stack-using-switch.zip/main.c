/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

********************************************************************************/
#include <stdio.h>
#include <stdlib.h>
int main()
{
        int Top=-1, stack[10],n,i,x;
        int choice;
        printf("Enter the size of stack:");
        scanf("%d",&n);
        while(1)
           {
               printf("\n 1.Push:Insert element in stack."); 
               printf("\n 2.Pop:delete element from stack.");
               printf("\n 3.Peek:show topmost element from the stack."); 
               printf("\n 4.Underflow:check whether the stack is empty.");
               printf("\n 5.Overflow:check whether the stack is full.");
               printf("\n 6.Display:show elements in stack.");
               printf("\n 7.Exit.");
               
               printf("\n Enter the choice:");
               scanf("\n %d",&choice);
               switch(choice)
               {
    case 1:
        if(Top==n-1)
        {
            printf("\n overflow!!");
        }
        else
        {
                printf("\n Enter the element to the stack:");
                scanf("%d",&x);
                Top=Top+1;
                stack[Top]=x;
        }
          break;
     case 2:
          if(Top==-1)
           {
               printf("\n Underflow!!");
           }
           else
           {  
               Top--;
           }
            break;
                    case 3:
                    printf("\n topmost element is %d",stack[Top]);
                     break;
                    case 4: 
                       if (Top==-1){
                           printf("\n Underflow!!");
                       }
                       else{
                           printf("\n not Underflow!!");
                       }
                     break;
                     case 5: 
                     if(Top==n-1){
                         printf("\n overflow!!");
                     }
                     else{
                         printf("\n not overflow1!");
                     }
                     break;
                     case 6: 
                          if(Top==-1){
                         printf("\n underflow!!");
                     }
                     for(int i=Top;i>=0;i--)
                     {
                         printf("\n %d",stack[i]);
                     }
                     break;
                     case 7: 
                             exit(0);
                     
                     default: 
                          printf("\n Invalid choice!");
                }
           }
}
