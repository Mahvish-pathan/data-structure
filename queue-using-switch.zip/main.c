/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <stdlib.h>

int main()
{
     int queue[10],n,i,x,f=-1,r=-1,Top;
        int choice;
        printf("Enter the size of queue:");
        scanf("%d",&n);
                   
        while(1)
           {
               printf("\n 1.Enque."); 
               printf("\n 2.Deque.");
               printf("\n 3.Underflow.");
               printf("\n 4.Overflow.");
               printf("\n 5.Display.");
               printf("\n 6.exit.");
              printf("\n Enter the choice:");
               scanf("\n %d",&choice);
               switch(choice)
            {
     //1.push
     case 1:
          printf("\n Enter the element for insertion in queuqe.");
          scanf("%d",&x);
          if(r==n-1)
          {
            printf("\n Overflow!!");  
          }
          else if(f==-1 && r==-1)
          {
              f=r=0;
              queue[r]=x;
          }
          else
          {
              r++;
              queue[r]=x;
          }
     break;
      case 2:
      printf("\n Enter the elements for deletion in queue:");
         scanf("%d",&x);
          if(f==-1 && r==-1)
           {
               printf("\n Underflow!!");
           }
           else if(f==r)
           {  
               printf("\n elements deleted from queue:%d",queue[f]);
               f=r=-1;
           }
           else
           {
               printf("\n elements deleted from queue:%d",queue[f]);
               f++;
           }
            break;
                     case 3: 
                        if(f==-1 && r==-1)
                        {
                            printf("queue is empty:Underflow");
                        }
                        else
                        {
                             printf("queue is not empty.");
                        }
                     break;
                     
                     case 4: 
                     if(r==n-1)
                     {
                         printf("Overflow!!");
                     }
                     else
                     {
                         printf("queue is not full.");
                     }
                     break;
                     
                    case 5: 
                    //Disply
                      if(f==n-1)
                      {
                        printf("\n Underflow!!");
                      }
                    else
                      {
                         printf("\n  element present in queue:");
                      
                         for(int i=f;i<=r;i++)
                         printf("%d\t",queue[i]);
                      }
                     break;
                     
                     case 6: 
                        exit(0);                     
                    break;
                    default: 
                          printf("\n Invalid choice!");
                      }     
           }
}



